require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const morgan = require('morgan');
const connectDB = require('./config/db');


const userRoutes = require('./routes/userRoutes');
const projectRoutes = require('./routes/projectRoutes');
const taskRoutes = require('./routes/taskRoutes');


const app = express();
const PORT = process.env.PORT || 3333;


// Middlewares
app.use(bodyParser.json());
app.use(morgan('dev'));


// Rotas
app.use('/api/users', userRoutes);
app.use('/api/projects', projectRoutes);
app.use('/api/tasks', taskRoutes);


app.get('/', (req, res) => res.send('API Gerenciador de Tarefas funcionando'));


// Conexão com DB e start
connectDB(process.env.MONGODB_URI || 'mongodb://localhost:27017/gerenciador_tarefas')
.then(() => {
app.listen(PORT, () => {
console.log(`Servidor rodando na porta ${PORT}`);
});
})
.catch(err => {
console.error('Erro iniciando servidor:', err);
});
